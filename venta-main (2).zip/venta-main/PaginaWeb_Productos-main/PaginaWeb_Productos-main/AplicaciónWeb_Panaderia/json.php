<? php
$ servidor = "localhost";
$ usuario = "root";
$ pase = "";
$ bd = "crud_basico";
// Creamos la conexión
$ conexion = mysqli_connect ($ servidor, $ usuario, $ pase, $ bd) 
or die ("Ha sucedido un error inexperado en la conexión de la base de datos");

// generamos la consulta
$ sql = "SELECT * FROM users";
mysqli_set_charset ($ conexión, "utf8"); // formato de datos utf8

if (! $ resultado = mysqli_query ($ conexión, $ sql)) die ();

$ usuarios = array (); // creamos un array
while ($ fila = mysqli_fetch_array ($ resultado)) 
{ 	
	$ nombre = $ fila ['nombre'];
	$ apellido1 = $ fila ['segundo nombre'];
	$ apellido2 = $ fila ['apellido'];
	$ fechaNac = $ fila ['fecha de nacimiento'];
	
	$ usuarios [] = array ('nombre' => $ nombre, 'apellido1' => $ apellido1, 'apellido2' => $ apellido2,
						'fechaNac' => $ fechaNac);

}
	
// desconectamos la base de datos
$ cerrar = mysqli_close ($ conexion) 
or die ("Ha sucedido un error inexperado en la desconexion de la base de datos");
  

// Creamos el JSON
$ json_string = json_encode ($ usuarios);
echo $ json_string;

// Si queremos crear un archivo json, sería de esta forma:
/ *
$ archivo = 'usuarios.json';
file_put_contents ($ archivo, $ json_string);
* /
	

?>